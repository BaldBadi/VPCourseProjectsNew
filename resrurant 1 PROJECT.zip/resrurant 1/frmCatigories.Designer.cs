﻿namespace resrurant_1
{
    partial class frmCatigories
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            button5 = new Button();
            button6 = new Button();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            button7 = new Button();
            button8 = new Button();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            button9 = new Button();
            button10 = new Button();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            textBox15 = new TextBox();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            button11 = new Button();
            button12 = new Button();
            textBox16 = new TextBox();
            textBox17 = new TextBox();
            textBox18 = new TextBox();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(14, 29);
            label1.Name = "label1";
            label1.Size = new Size(39, 20);
            label1.TabIndex = 0;
            label1.Text = "Item";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 65);
            label2.Name = "label2";
            label2.Size = new Size(65, 20);
            label2.TabIndex = 1;
            label2.Text = "Quantity";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(14, 105);
            label3.Name = "label3";
            label3.Size = new Size(69, 20);
            label3.TabIndex = 2;
            label3.Text = "Exp Date";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(85, 26);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(85, 62);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 27);
            textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(85, 102);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 27);
            textBox3.TabIndex = 5;
            // 
            // button1
            // 
            button1.Location = new Point(14, 146);
            button1.Name = "button1";
            button1.Size = new Size(98, 37);
            button1.TabIndex = 6;
            button1.Text = "Edit";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(129, 146);
            button2.Name = "button2";
            button2.Size = new Size(98, 37);
            button2.TabIndex = 7;
            button2.Text = "Request";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(377, 146);
            button3.Name = "button3";
            button3.Size = new Size(98, 37);
            button3.TabIndex = 15;
            button3.Text = "Request";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(262, 146);
            button4.Name = "button4";
            button4.Size = new Size(98, 37);
            button4.TabIndex = 14;
            button4.Text = "Edit";
            button4.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(333, 102);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 27);
            textBox4.TabIndex = 13;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(333, 62);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(125, 27);
            textBox5.TabIndex = 12;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(333, 26);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(125, 27);
            textBox6.TabIndex = 11;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(262, 105);
            label4.Name = "label4";
            label4.Size = new Size(69, 20);
            label4.TabIndex = 10;
            label4.Text = "Exp Date";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(262, 65);
            label5.Name = "label5";
            label5.Size = new Size(65, 20);
            label5.TabIndex = 9;
            label5.Text = "Quantity";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(262, 29);
            label6.Name = "label6";
            label6.Size = new Size(39, 20);
            label6.TabIndex = 8;
            label6.Text = "Item";
            // 
            // button5
            // 
            button5.Location = new Point(626, 146);
            button5.Name = "button5";
            button5.Size = new Size(98, 37);
            button5.TabIndex = 23;
            button5.Text = "Request";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(511, 146);
            button6.Name = "button6";
            button6.Size = new Size(98, 37);
            button6.TabIndex = 22;
            button6.Text = "Edit";
            button6.UseVisualStyleBackColor = true;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(582, 102);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(125, 27);
            textBox7.TabIndex = 21;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(582, 62);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(125, 27);
            textBox8.TabIndex = 20;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(582, 26);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(125, 27);
            textBox9.TabIndex = 19;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(511, 105);
            label7.Name = "label7";
            label7.Size = new Size(69, 20);
            label7.TabIndex = 18;
            label7.Text = "Exp Date";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(511, 65);
            label8.Name = "label8";
            label8.Size = new Size(65, 20);
            label8.TabIndex = 17;
            label8.Text = "Quantity";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(511, 29);
            label9.Name = "label9";
            label9.Size = new Size(39, 20);
            label9.TabIndex = 16;
            label9.Text = "Item";
            // 
            // button7
            // 
            button7.Location = new Point(129, 368);
            button7.Name = "button7";
            button7.Size = new Size(98, 37);
            button7.TabIndex = 31;
            button7.Text = "Request";
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(14, 368);
            button8.Name = "button8";
            button8.Size = new Size(98, 37);
            button8.TabIndex = 30;
            button8.Text = "Edit";
            button8.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(85, 324);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(125, 27);
            textBox10.TabIndex = 29;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(85, 284);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(125, 27);
            textBox11.TabIndex = 28;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(85, 248);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(125, 27);
            textBox12.TabIndex = 27;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(14, 327);
            label10.Name = "label10";
            label10.Size = new Size(69, 20);
            label10.TabIndex = 26;
            label10.Text = "Exp Date";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(14, 287);
            label11.Name = "label11";
            label11.Size = new Size(65, 20);
            label11.TabIndex = 25;
            label11.Text = "Quantity";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(14, 251);
            label12.Name = "label12";
            label12.Size = new Size(39, 20);
            label12.TabIndex = 24;
            label12.Text = "Item";
            // 
            // button9
            // 
            button9.Location = new Point(377, 368);
            button9.Name = "button9";
            button9.Size = new Size(98, 37);
            button9.TabIndex = 39;
            button9.Text = "Request";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(262, 368);
            button10.Name = "button10";
            button10.Size = new Size(98, 37);
            button10.TabIndex = 38;
            button10.Text = "Edit";
            button10.UseVisualStyleBackColor = true;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(333, 324);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(125, 27);
            textBox13.TabIndex = 37;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(333, 284);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(125, 27);
            textBox14.TabIndex = 36;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(333, 248);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(125, 27);
            textBox15.TabIndex = 35;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(262, 327);
            label13.Name = "label13";
            label13.Size = new Size(69, 20);
            label13.TabIndex = 34;
            label13.Text = "Exp Date";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(262, 287);
            label14.Name = "label14";
            label14.Size = new Size(65, 20);
            label14.TabIndex = 33;
            label14.Text = "Quantity";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(262, 251);
            label15.Name = "label15";
            label15.Size = new Size(39, 20);
            label15.TabIndex = 32;
            label15.Text = "Item";
            // 
            // button11
            // 
            button11.Location = new Point(626, 371);
            button11.Name = "button11";
            button11.Size = new Size(98, 37);
            button11.TabIndex = 47;
            button11.Text = "Request";
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(511, 371);
            button12.Name = "button12";
            button12.Size = new Size(98, 37);
            button12.TabIndex = 46;
            button12.Text = "Edit";
            button12.UseVisualStyleBackColor = true;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(582, 327);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(125, 27);
            textBox16.TabIndex = 45;
            // 
            // textBox17
            // 
            textBox17.Location = new Point(582, 287);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(125, 27);
            textBox17.TabIndex = 44;
            // 
            // textBox18
            // 
            textBox18.Location = new Point(582, 251);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(125, 27);
            textBox18.TabIndex = 43;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(511, 330);
            label16.Name = "label16";
            label16.Size = new Size(69, 20);
            label16.TabIndex = 42;
            label16.Text = "Exp Date";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(511, 290);
            label17.Name = "label17";
            label17.Size = new Size(65, 20);
            label17.TabIndex = 41;
            label17.Text = "Quantity";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(511, 254);
            label18.Name = "label18";
            label18.Size = new Size(39, 20);
            label18.TabIndex = 40;
            label18.Text = "Item";
            // 
            // frmCatigories
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(textBox16);
            Controls.Add(textBox17);
            Controls.Add(textBox18);
            Controls.Add(label16);
            Controls.Add(label17);
            Controls.Add(label18);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(textBox13);
            Controls.Add(textBox14);
            Controls.Add(textBox15);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label15);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(textBox10);
            Controls.Add(textBox11);
            Controls.Add(textBox12);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(textBox7);
            Controls.Add(textBox8);
            Controls.Add(textBox9);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(button3);
            Controls.Add(button4);
            Controls.Add(textBox4);
            Controls.Add(textBox5);
            Controls.Add(textBox6);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmCatigories";
            Text = "frmCatigories";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button button5;
        private Button button6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private Label label7;
        private Label label8;
        private Label label9;
        private Button button7;
        private Button button8;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private Label label10;
        private Label label11;
        private Label label12;
        private Button button9;
        private Button button10;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private Label label13;
        private Label label14;
        private Label label15;
        private Button button11;
        private Button button12;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox18;
        private Label label16;
        private Label label17;
        private Label label18;
    }
}