﻿namespace resrurant_1
{
    partial class frmKitchien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            button1 = new Button();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            textBox15 = new TextBox();
            textBox16 = new TextBox();
            textBox17 = new TextBox();
            textBox18 = new TextBox();
            textBox19 = new TextBox();
            textBox20 = new TextBox();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            button2 = new Button();
            button3 = new Button();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            button4 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(36, 45);
            label1.Name = "label1";
            label1.Size = new Size(44, 20);
            label1.TabIndex = 0;
            label1.Text = "Table";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 79);
            label2.Name = "label2";
            label2.Size = new Size(93, 20);
            label2.TabIndex = 1;
            label2.Text = "Waiter name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 108);
            label3.Name = "label3";
            label3.Size = new Size(88, 20);
            label3.TabIndex = 2;
            label3.Text = "Order name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(27, 141);
            label4.Name = "label4";
            label4.Size = new Size(80, 20);
            label4.TabIndex = 3;
            label4.Text = "Order type";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(36, 178);
            label5.Name = "label5";
            label5.Size = new Size(47, 20);
            label5.TabIndex = 4;
            label5.Text = "Order";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(118, 42);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(118, 75);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 27);
            textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(118, 108);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 27);
            textBox3.TabIndex = 7;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(118, 138);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 27);
            textBox4.TabIndex = 8;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(118, 171);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(125, 27);
            textBox5.TabIndex = 9;
            // 
            // button1
            // 
            button1.Location = new Point(77, 234);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 10;
            button1.Text = "Complete";
            button1.UseVisualStyleBackColor = true;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(351, 171);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(125, 27);
            textBox6.TabIndex = 20;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(351, 138);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(125, 27);
            textBox7.TabIndex = 19;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(351, 105);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(125, 27);
            textBox8.TabIndex = 18;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(351, 72);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(125, 27);
            textBox9.TabIndex = 17;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(351, 38);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(125, 27);
            textBox10.TabIndex = 16;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(599, 170);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(125, 27);
            textBox11.TabIndex = 31;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(599, 137);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(125, 27);
            textBox12.TabIndex = 30;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(599, 105);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(125, 27);
            textBox13.TabIndex = 29;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(599, 72);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(125, 27);
            textBox14.TabIndex = 28;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(599, 38);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(125, 27);
            textBox15.TabIndex = 27;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(118, 441);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(125, 27);
            textBox16.TabIndex = 42;
            // 
            // textBox17
            // 
            textBox17.Location = new Point(118, 408);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(125, 27);
            textBox17.TabIndex = 41;
            // 
            // textBox18
            // 
            textBox18.Location = new Point(118, 375);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(125, 27);
            textBox18.TabIndex = 40;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(118, 342);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(125, 27);
            textBox19.TabIndex = 39;
            // 
            // textBox20
            // 
            textBox20.Location = new Point(118, 308);
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(125, 27);
            textBox20.TabIndex = 38;
            // 
            // button5
            // 
            button5.Location = new Point(36, 553);
            button5.Name = "button5";
            button5.Size = new Size(148, 50);
            button5.TabIndex = 44;
            button5.Text = "Add";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(206, 554);
            button6.Name = "button6";
            button6.Size = new Size(148, 50);
            button6.TabIndex = 45;
            button6.Text = "Edit";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(376, 554);
            button7.Name = "button7";
            button7.Size = new Size(148, 50);
            button7.TabIndex = 46;
            button7.Text = "Delete";
            button7.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(269, 181);
            label6.Name = "label6";
            label6.Size = new Size(47, 20);
            label6.TabIndex = 51;
            label6.Text = "Order";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(260, 144);
            label7.Name = "label7";
            label7.Size = new Size(80, 20);
            label7.TabIndex = 50;
            label7.Text = "Order type";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(252, 111);
            label8.Name = "label8";
            label8.Size = new Size(88, 20);
            label8.TabIndex = 49;
            label8.Text = "Order name";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(252, 82);
            label9.Name = "label9";
            label9.Size = new Size(93, 20);
            label9.TabIndex = 48;
            label9.Text = "Waiter name";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(269, 48);
            label10.Name = "label10";
            label10.Size = new Size(44, 20);
            label10.TabIndex = 47;
            label10.Text = "Table";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(517, 171);
            label11.Name = "label11";
            label11.Size = new Size(47, 20);
            label11.TabIndex = 56;
            label11.Text = "Order";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(508, 134);
            label12.Name = "label12";
            label12.Size = new Size(80, 20);
            label12.TabIndex = 55;
            label12.Text = "Order type";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(500, 101);
            label13.Name = "label13";
            label13.Size = new Size(88, 20);
            label13.TabIndex = 54;
            label13.Text = "Order name";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(500, 72);
            label14.Name = "label14";
            label14.Size = new Size(93, 20);
            label14.TabIndex = 53;
            label14.Text = "Waiter name";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(517, 38);
            label15.Name = "label15";
            label15.Size = new Size(44, 20);
            label15.TabIndex = 52;
            label15.Text = "Table";
            // 
            // button2
            // 
            button2.Location = new Point(312, 234);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 57;
            button2.Text = "Complete";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(559, 234);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 58;
            button3.Text = "Complete";
            button3.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(39, 448);
            label16.Name = "label16";
            label16.Size = new Size(47, 20);
            label16.TabIndex = 63;
            label16.Text = "Order";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(30, 411);
            label17.Name = "label17";
            label17.Size = new Size(80, 20);
            label17.TabIndex = 62;
            label17.Text = "Order type";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(22, 378);
            label18.Name = "label18";
            label18.Size = new Size(88, 20);
            label18.TabIndex = 61;
            label18.Text = "Order name";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(22, 349);
            label19.Name = "label19";
            label19.Size = new Size(93, 20);
            label19.TabIndex = 60;
            label19.Text = "Waiter name";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(39, 315);
            label20.Name = "label20";
            label20.Size = new Size(44, 20);
            label20.TabIndex = 59;
            label20.Text = "Table";
            // 
            // button4
            // 
            button4.Location = new Point(77, 501);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 64;
            button4.Text = "Complete";
            button4.UseVisualStyleBackColor = true;
            // 
            // frmKitchien
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(962, 616);
            Controls.Add(button4);
            Controls.Add(label16);
            Controls.Add(label17);
            Controls.Add(label18);
            Controls.Add(label19);
            Controls.Add(label20);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label15);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(textBox16);
            Controls.Add(textBox17);
            Controls.Add(textBox18);
            Controls.Add(textBox19);
            Controls.Add(textBox20);
            Controls.Add(textBox11);
            Controls.Add(textBox12);
            Controls.Add(textBox13);
            Controls.Add(textBox14);
            Controls.Add(textBox15);
            Controls.Add(textBox6);
            Controls.Add(textBox7);
            Controls.Add(textBox8);
            Controls.Add(textBox9);
            Controls.Add(textBox10);
            Controls.Add(button1);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmKitchien";
            Text = "frmKitchien";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private Button button1;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox18;
        private TextBox textBox19;
        private TextBox textBox20;
        private Button button5;
        private Button button6;
        private Button button7;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Button button2;
        private Button button3;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Button button4;
    }
}