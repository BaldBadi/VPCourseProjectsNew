﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace resrurant_1
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pnlData.Controls.Clear();
            frmHome frm = new frmHome() { TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            pnlData.Controls.Add(frm);
            frm.Show();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            pnlData.Controls.Clear();
            frmCatigories frm = new frmCatigories() { TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            pnlData.Controls.Add(frm);
            frm.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            pnlData.Controls.Clear();
            frmKitchien frm = new frmKitchien() { TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            pnlData.Controls.Add(frm);
            frm.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            pnlData.Controls.Clear();
            frmStaff frm = new frmStaff() { TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            pnlData.Controls.Add(frm);
            frm.Show();
        }
    }
}
