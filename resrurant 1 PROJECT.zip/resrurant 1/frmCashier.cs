﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace resrurant_1
{
    public partial class frmCashier : Form
    {
        public frmCashier()
        {
            InitializeComponent();
        }

        private void btnMain_Click(object sender, EventArgs e)
        {
            PnlShow.Controls.Clear();
            frmMainMeals frm = new frmMainMeals() { TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            PnlShow.Controls.Add(frm);
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PnlShow.Controls.Clear();
            frmSnaks frm = new frmSnaks() { TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            PnlShow.Controls.Add(frm);
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PnlShow.Controls.Clear();
            frmDrinks frm = new frmDrinks() { TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            PnlShow.Controls.Add(frm);
            frm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PnlShow.Controls.Clear();
            frmSauce frm = new frmSauce() { TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.None;
            PnlShow.Controls.Add(frm);
            frm.Show();
        }
    }
}
