﻿namespace resrurant_1
{
    partial class frmCashier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCashier));
            panel1 = new Panel();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            btnMain = new Button();
            panel2 = new Panel();
            PnlShow = new Panel();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btnMain);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(149, 518);
            panel1.TabIndex = 0;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ActiveCaption;
            button3.FlatAppearance.BorderColor = SystemColors.ActiveCaption;
            button3.Location = new Point(16, 340);
            button3.Name = "button3";
            button3.Size = new Size(121, 40);
            button3.TabIndex = 4;
            button3.Text = "Sauce";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveCaption;
            button2.FlatAppearance.BorderColor = SystemColors.ActiveCaption;
            button2.Location = new Point(16, 285);
            button2.Name = "button2";
            button2.Size = new Size(121, 40);
            button2.TabIndex = 3;
            button2.Text = "Drinks";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveCaption;
            button1.FlatAppearance.BorderColor = SystemColors.ActiveCaption;
            button1.Location = new Point(16, 224);
            button1.Name = "button1";
            button1.Size = new Size(121, 40);
            button1.TabIndex = 2;
            button1.Text = "Snaks";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(125, 88);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // btnMain
            // 
            btnMain.BackColor = SystemColors.ActiveCaption;
            btnMain.FlatAppearance.BorderColor = SystemColors.ActiveCaption;
            btnMain.Location = new Point(16, 165);
            btnMain.Name = "btnMain";
            btnMain.Size = new Size(121, 40);
            btnMain.TabIndex = 0;
            btnMain.Text = "Main Meals";
            btnMain.UseVisualStyleBackColor = false;
            btnMain.Click += btnMain_Click;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ActiveBorder;
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(149, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(681, 82);
            panel2.TabIndex = 1;
            // 
            // PnlShow
            // 
            PnlShow.Dock = DockStyle.Fill;
            PnlShow.Location = new Point(149, 82);
            PnlShow.Name = "PnlShow";
            PnlShow.Size = new Size(681, 436);
            PnlShow.TabIndex = 2;
            // 
            // frmCashier
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(830, 518);
            Controls.Add(PnlShow);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "frmCashier";
            Text = "frmCashier";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox1;
        private Button btnMain;
        private Panel panel2;
        private Button button3;
        private Button button2;
        private Button button1;
        private Panel PnlShow;
    }
}