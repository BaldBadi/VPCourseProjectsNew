using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace resrurant_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnlog_Click(object sender, EventArgs e)
        {
            if (txtuser.Text == "Manager")
            {
                frmMain frm = new frmMain();
                frm.Show();
            }
            else if (txtuser.Text =="Cashier")
            {
                frmCashier frm = new frmCashier();
                frm.Show();
            }
            else Application.Exit();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmCashier frm = new frmCashier();
            frm.Show();
        }
    }
}