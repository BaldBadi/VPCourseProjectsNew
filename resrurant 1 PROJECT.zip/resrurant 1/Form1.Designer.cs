﻿namespace resrurant_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            label1 = new Label();
            txtuser = new TextBox();
            txtpassword = new TextBox();
            label2 = new Label();
            btnlog = new Button();
            btnexit = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label3);
            panel1.Dock = DockStyle.Top;
            panel1.ForeColor = SystemColors.ActiveCaptionText;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(357, 183);
            panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(77, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(182, 151);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ActiveCaption;
            label3.ForeColor = Color.Transparent;
            label3.Location = new Point(6, 158);
            label3.Name = "label3";
            label3.Size = new Size(205, 20);
            label3.TabIndex = 0;
            label3.Text = "please enter your information";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 197);
            label1.Name = "label1";
            label1.Size = new Size(75, 20);
            label1.TabIndex = 1;
            label1.Text = "Username";
            // 
            // txtuser
            // 
            txtuser.BackColor = SystemColors.HighlightText;
            txtuser.Location = new Point(12, 220);
            txtuser.Multiline = true;
            txtuser.Name = "txtuser";
            txtuser.Size = new Size(279, 32);
            txtuser.TabIndex = 2;
            // 
            // txtpassword
            // 
            txtpassword.Location = new Point(12, 292);
            txtpassword.Multiline = true;
            txtpassword.Name = "txtpassword";
            txtpassword.Size = new Size(279, 32);
            txtpassword.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 269);
            label2.Name = "label2";
            label2.Size = new Size(70, 20);
            label2.TabIndex = 3;
            label2.Text = "Password";
            // 
            // btnlog
            // 
            btnlog.BackColor = Color.FromArgb(192, 192, 255);
            btnlog.Cursor = Cursors.Hand;
            btnlog.FlatAppearance.BorderColor = Color.FromArgb(192, 192, 255);
            btnlog.FlatStyle = FlatStyle.Flat;
            btnlog.ForeColor = Color.White;
            btnlog.Location = new Point(41, 379);
            btnlog.Name = "btnlog";
            btnlog.Size = new Size(94, 44);
            btnlog.TabIndex = 5;
            btnlog.Text = "log in";
            btnlog.UseVisualStyleBackColor = false;
            btnlog.Click += btnlog_Click;
            // 
            // btnexit
            // 
            btnexit.BackColor = Color.Red;
            btnexit.Cursor = Cursors.Hand;
            btnexit.FlatAppearance.BorderColor = Color.Red;
            btnexit.FlatStyle = FlatStyle.Flat;
            btnexit.ForeColor = Color.White;
            btnexit.Location = new Point(165, 379);
            btnexit.Name = "btnexit";
            btnexit.Size = new Size(94, 44);
            btnexit.TabIndex = 6;
            btnexit.Text = "Exit";
            btnexit.UseVisualStyleBackColor = false;
            btnexit.Click += btnexit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(357, 435);
            Controls.Add(btnexit);
            Controls.Add(btnlog);
            Controls.Add(txtpassword);
            Controls.Add(label2);
            Controls.Add(txtuser);
            Controls.Add(label1);
            Controls.Add(panel1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Form1";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private TextBox txtuser;
        private TextBox txtpassword;
        private Label label2;
        private Button btnlog;
        private Button btnexit;
        private PictureBox pictureBox1;
        private Label label3;
    }
}