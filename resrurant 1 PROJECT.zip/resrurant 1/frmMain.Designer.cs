﻿namespace resrurant_1
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            panel1 = new Panel();
            btnstaff = new Button();
            btnkitchen = new Button();
            btncatigories = new Button();
            btnHome = new Button();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            button3 = new Button();
            button2 = new Button();
            label2 = new Label();
            btnExit = new Button();
            pnlData = new Panel();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.Controls.Add(btnstaff);
            panel1.Controls.Add(btnkitchen);
            panel1.Controls.Add(btncatigories);
            panel1.Controls.Add(btnHome);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(150, 450);
            panel1.TabIndex = 0;
            // 
            // btnstaff
            // 
            btnstaff.AccessibleRole = AccessibleRole.RadioButton;
            btnstaff.FlatAppearance.BorderColor = SystemColors.ActiveCaption;
            btnstaff.FlatStyle = FlatStyle.Flat;
            btnstaff.Image = (Image)resources.GetObject("btnstaff.Image");
            btnstaff.ImageAlign = ContentAlignment.MiddleLeft;
            btnstaff.Location = new Point(12, 318);
            btnstaff.Name = "btnstaff";
            btnstaff.Size = new Size(120, 37);
            btnstaff.TabIndex = 8;
            btnstaff.Text = "Staff";
            btnstaff.UseVisualStyleBackColor = true;
            btnstaff.Click += button7_Click;
            // 
            // btnkitchen
            // 
            btnkitchen.AccessibleRole = AccessibleRole.RadioButton;
            btnkitchen.FlatAppearance.BorderColor = SystemColors.ActiveCaption;
            btnkitchen.FlatStyle = FlatStyle.Flat;
            btnkitchen.Image = (Image)resources.GetObject("btnkitchen.Image");
            btnkitchen.ImageAlign = ContentAlignment.MiddleLeft;
            btnkitchen.Location = new Point(12, 263);
            btnkitchen.Name = "btnkitchen";
            btnkitchen.Size = new Size(120, 49);
            btnkitchen.TabIndex = 7;
            btnkitchen.Text = "Kitchen";
            btnkitchen.UseVisualStyleBackColor = true;
            btnkitchen.Click += button6_Click;
            // 
            // btncatigories
            // 
            btncatigories.AccessibleRole = AccessibleRole.RadioButton;
            btncatigories.FlatAppearance.BorderColor = SystemColors.ActiveCaption;
            btncatigories.FlatStyle = FlatStyle.Flat;
            btncatigories.Image = (Image)resources.GetObject("btncatigories.Image");
            btncatigories.ImageAlign = ContentAlignment.MiddleLeft;
            btncatigories.Location = new Point(3, 208);
            btncatigories.Name = "btncatigories";
            btncatigories.Size = new Size(141, 49);
            btncatigories.TabIndex = 6;
            btncatigories.Text = "Catigories";
            btncatigories.UseVisualStyleBackColor = true;
            btncatigories.Click += button5_Click;
            // 
            // btnHome
            // 
            btnHome.AccessibleRole = AccessibleRole.RadioButton;
            btnHome.FlatAppearance.BorderColor = SystemColors.ActiveCaption;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.Image = (Image)resources.GetObject("btnHome.Image");
            btnHome.ImageAlign = ContentAlignment.MiddleLeft;
            btnHome.Location = new Point(12, 165);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(120, 49);
            btnHome.TabIndex = 1;
            btnHome.Text = "Home";
            btnHome.UseVisualStyleBackColor = true;
            btnHome.Click += button4_Click;
            // 
            // label1
            // 
            label1.Location = new Point(3, 110);
            label1.Name = "label1";
            label1.Size = new Size(141, 68);
            label1.TabIndex = 5;
            label1.Text = "Resturant Managment System";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(109, 76);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ActiveBorder;
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(btnExit);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(150, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(650, 59);
            panel2.TabIndex = 1;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button3.BackColor = SystemColors.ActiveCaption;
            button3.Location = new Point(524, 12);
            button3.Name = "button3";
            button3.Size = new Size(54, 29);
            button3.TabIndex = 5;
            button3.Text = "□";
            button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button2.BackColor = SystemColors.ActiveCaption;
            button2.Location = new Point(464, 12);
            button2.Name = "button2";
            button2.Size = new Size(54, 29);
            button2.TabIndex = 4;
            button2.Text = "-";
            button2.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(25, 27);
            label2.Name = "label2";
            label2.Size = new Size(50, 20);
            label2.TabIndex = 3;
            label2.Text = "label2";
            // 
            // btnExit
            // 
            btnExit.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnExit.BackColor = Color.Red;
            btnExit.Location = new Point(584, 12);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(54, 29);
            btnExit.TabIndex = 0;
            btnExit.Text = "X";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // pnlData
            // 
            pnlData.Dock = DockStyle.Fill;
            pnlData.Location = new Point(150, 59);
            pnlData.Name = "pnlData";
            pnlData.Size = new Size(650, 391);
            pnlData.TabIndex = 2;
            // 
            // frmMain
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pnlData);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "frmMain";
            Text = "frmMain";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button btnHome;
        private PictureBox pictureBox1;
        private Panel panel2;
        private Button btnExit;
        private Panel pnlData;
        private Label label1;
        private Label label2;
        private Button button3;
        private Button button2;
        private Button btnstaff;
        private Button btnkitchen;
        private Button btncatigories;
    }
}